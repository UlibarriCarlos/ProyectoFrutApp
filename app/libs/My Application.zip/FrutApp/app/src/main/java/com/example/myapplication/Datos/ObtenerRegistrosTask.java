package com.example.myapplication.Datos;

import android.os.AsyncTask;
import java.sql.*;
import java.util.*;

public class ObtenerRegistrosTask extends AsyncTask<Void, Void, List<Map<String, Object>>> {

    private String connectionString;
    private String usuario;
    private String contrasena;
    private String nombreTabla;

    public ObtenerRegistrosTask(String connectionString, String usuario, String contrasena, String nombreTabla) {
        this.connectionString = connectionString;
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.nombreTabla = nombreTabla;
    }

    @Override
    protected List<Map<String, Object>> doInBackground(Void... voids) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        List<Map<String, Object>> dataList = new ArrayList<>();
        try {
            // Paso 1: Cargar el driver de JDBC
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Paso 2: Establecer la conexión con la base de datos
            conn = DriverManager.getConnection(connectionString, usuario, contrasena);

            // Paso 3: Crear un objeto Statement para ejecutar consultas SQL
            stmt = conn.createStatement();

            // Paso 4: Ejecutar una consulta SELECT y obtener un ResultSet
            String consulta = "SELECT * FROM " + nombreTabla;
            rs = stmt.executeQuery(consulta);

            // Paso 5: Almacenar los resultados en una lista de mapas
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, Object> rowMap = new HashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    rowMap.put(metaData.getColumnName(i), rs.getObject(i));
                }
                dataList.add(rowMap);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // Paso 6: Cerrar los objetos ResultSet, Statement y Connection
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return dataList;
    }
}
