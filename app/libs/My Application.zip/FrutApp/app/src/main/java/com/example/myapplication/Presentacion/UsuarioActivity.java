package com.example.myapplication.Presentacion;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Datos.ObtenerRegistrosTask;
import com.example.myapplication.R;
import com.example.myapplication.Datos.MySQLConnection;

import java.sql.Connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class UsuarioActivity extends AppCompatActivity {
    private EditText et_nombre, et_contraseña;
    private Button btn_loginUsuario;
    private TextView tv_registrarse;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.usuario);
        //Login
        et_nombre = findViewById(R.id.etNombre);
        et_contraseña = findViewById(R.id.etPassword);
        btn_loginUsuario = findViewById(R.id.btnLogin);
        tv_registrarse = findViewById(R.id.tvSignUp);

        btn_loginUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Registarmos acciones en Logcat
                Log.v("LogUsuario", "Boton Login usuario pulsado");
                //ObtenerRegistrosTask task = new ObtenerRegistrosTask("jdbc:jtds:sqlserver://localhost;databaseName=FrutApp;", "2222", "1234", "tbClientes");

                connectToMySQL();


               // Intent intent1 = new Intent(UsuarioActivity.this, PrincipalActivity.class);
              //  startActivity(intent1);

            }

        });

        tv_registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(UsuarioActivity.this, RegistroActivity.class);
                startActivity(intent1);
            }
        });

    }

    public void connectToMySQL() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1:3306/futapp";
            String user = "root";
            String password = "";
            Connection connection = DriverManager.getConnection(url, user, password);

            Toast.makeText(UsuarioActivity.this, "Conexioin OK", Toast.LENGTH_LONG).show();
            // Realiza acciones con la conexión...
            connection.close(); // Cierra la conexión una vez que ya no se necesite
        } catch (ClassNotFoundException e) {
            e.printStackTrace();


        } catch (SQLException e) {
            e.printStackTrace();
            Toast.makeText(UsuarioActivity.this, "Conexioin No OK", Toast.LENGTH_LONG).show();
        }
    }
}





